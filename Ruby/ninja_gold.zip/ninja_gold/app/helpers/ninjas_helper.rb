module NinjasHelper
end
