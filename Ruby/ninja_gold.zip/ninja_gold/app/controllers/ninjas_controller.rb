class NinjasController < ApplicationController
  def index

    if !session[:gold]
      session[:gold] = 0
      session[:activities] = []
    end
    @gold = session[:gold]
    @activities = session[:activities]
    # @activities.all
  end

  def farm
    amount = rand(10..20)
    session[:gold] += amount

    obj = {won: true, sentence: "You won #{amount} from farm"}
    session[:activities].push(obj)
    redirect_to '/'
  end

  def cave
    amount = rand(5..10)
    session[:gold] += amount
    obj = {won: true, sentence: "You won #{amount} from farm"}
    session[:activities].push(obj)
    redirect_to '/'
  end

  def house
    amount = rand(2..5)
    session[:gold] += amount
    obj = {won: true, sentence: "You won #{amount} from farm"}
    session[:activities].push(obj)
    redirect_to '/'
  end

  def casino
    amount = rand(0..50)
    gamble = rand(1..2)
    if gamble == 1
      session[:gold] += amount
      obj = {won: true, sentence: "You won #{amount} from farm"}
      session[:activities].push(obj)
    else
      session[:gold] -= amount
      obj = {won: false, sentence: "You lost #{amount} from farm"}
      session[:activities].push(obj)
    end

    # session[:gold] += amount

    redirect_to '/'
  end

end
