class SaysController < ApplicationController
end
