class UsersController < ApplicationController
  def new
    render "new"
  end

  def index
    render text: "index"
  end
end
