from flask import Flask, render_template, redirect, request
import re
from mysqlconnection import MySQLConnector
app = Flask(__name__)
mysql = MySQLConnector(app, 'emaildb')

@app.route('/')
def index():
    # allemails = mysql.query_db("SELECT * FROM emails")
    # print "got all the emails", allemails
    return render_template('index.html')
@app.route('/process', methods = ['POST'])
def process():
    EMAIL_REGEX = (r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
    print "made it to the process route"
    email = request.form['email']
    if re.match(EMAIL_REGEX,email):
        query = "INSERT INTO emails (email, created_at, updated_at) VALUES (:email,NOW(),NOW())"
        data = {
            'email':request.form['email'] #.strftime("%m/%d/%Y %I:%M %p")
        }
        mysql.query_db(query, data)
        print "We have a valid email", email
        return redirect("/success")
    else:
        print "Not a valid email", email
        return render_template("index.html", invalid = "This is not a valid email")


@app.route('/success')
def success():
    emailsname = mysql.query_db("SELECT email FROM emails")
    emailsdate = mysql.query_db("SELECT created_at FROM emails")
    return render_template('success.html', emailsname1 = emailsname, emailsdate1 = emailsdate)

app.run(debug=True)
