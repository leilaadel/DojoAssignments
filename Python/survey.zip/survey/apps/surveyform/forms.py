from django import forms

class PostForm(forms.Form):
    fields = ('name', 'location','language','comment')
