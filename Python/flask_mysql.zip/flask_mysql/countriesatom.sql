-- 1
SELECT *
FROM languages
WHERE language LIKE "Slovene"
ORDER by percentage DESC;
-- 2
SELECT *
FROM cities
ORDER BY id DESC;
-- 3
SELECT *
FROM cities
WHERE population > 500000 && country_code = 'MEX'
ORDER BY population DESC;
--4
SELECT *
FROM languages
WHERE percentage > 89
ORDER BY percentage DESC;
-- 5
SELECT *
FROM countries
WHERE population > 100000 && surface_area < 501;
--6
SELECT *
FROM countries
WHERE government_form = 'Constitutional Monarchy' && capital > 200 && life_expectancy > 75;
--7
SELECT *
FROM cities
WHERE population > 500000 && district = 'Buenos Aires';
--8
