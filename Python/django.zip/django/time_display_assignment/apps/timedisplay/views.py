# from django.shortcuts import render, HttpResponse, datetime
#   # Create your views here.
# def index(request):
#     today = datetime.now()
#     print str(today)
#     # response = "Hello, I am your first request!"
#     # return HttpResponse(response)
#     return render(request, "timedisplay/index.html")

from django.shortcuts import render, HttpResponse
import datetime
def index(request):
    now = datetime.datetime.now()
    return render(request,'timedisplay/index.html', {'now':now})
# def index(request):
#     # today = datetime.now()
#     # print str(today)
#     # response = "Hello, I am your first request!"
#     # return HttpResponse(response)
#     return render(request, "timedisplay/index.html")
