from django.shortcuts import render, HttpResponse, redirect
import random, string

def index(request):
    attempt1 = 0
    if request.method == "POST":
     if 'attempt1' not in request.session:
         request.session['attempt1'] = 1
     else:
         request.session['attempt1'] += 1

     print attempt1
     attempt1 = attempt1 + 1
     anything = "".join(random.choice(string.lowercase) for i in range(14))
     return render(request, "rwg/index.html", {'anything':anything}, {'attempt1':attempt1})
    else:
     print "else statement"
     return render(request, "rwg/index.html")



def create(request):
    print "you got to create"
    return redirect("/")
